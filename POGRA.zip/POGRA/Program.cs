﻿Console.WriteLine("Ingrese su nombre: ");
string Nombre = Console.ReadLine();

Console.WriteLine("Hola Mundo");
Console.WriteLine("soy " + Nombre);